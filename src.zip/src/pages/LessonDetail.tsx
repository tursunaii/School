export function LessonDetail() {
  return (
    <div>
      
    </div>
  )
}
