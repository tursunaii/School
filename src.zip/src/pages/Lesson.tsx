import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  BookOpen,
  Download,
  Share2,
  Heart,
  Bookmark,
  MessageCircle,
  Clock,
  User,
  CheckCircle,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  Settings,
  Fullscreen,
  SkipForward,
  SkipBack
} from 'lucide-react'
import { subjectsData } from './Subjects'
import { useParams } from 'react-router-dom'
import Plyr from "plyr";
import "plyr/dist/plyr.css";
// import { Play } from "lucide-react";

export function Lesson() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(1800) // 30 minutes in seconds
  const [volume, setVolume] = useState(80)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [activeTab, setActiveTab] = useState('video')
  const { id } = useParams()

  const comments = [
    {
      id: 1,
      author: 'Айбек Токтогулов',
      avatar: '/api/placeholder/32/32',
      text: 'Отличный урок! Очень понятно объясняется.',
      time: '5 минут назад',
      likes: 12
    },
    {
      id: 2,
      author: 'Гульнара Асанова',
      avatar: '/api/placeholder/32/32',
      text: 'Спасибо за подробное объяснение формул.',
      time: '10 минут назад',
      likes: 8
    },
    {
      id: 3,
      author: 'Эркин Абдыкадыров',
      avatar: '/api/placeholder/32/32',
      text: 'Можно ли получить дополнительные примеры?',
      time: '15 минут назад',
      likes: 5
    }
  ]

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying)
  }

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setVolume(Number(e.target.value))
  }

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCurrentTime(Number(e.target.value))
  }

  const handleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  const lesson = subjectsData.filter(subj => subj.id === Number(id))[0]
  console.log(lesson);

  const playerRef = useRef<HTMLDivElement>(null);

   useEffect(() => {
    const player = new Plyr(playerRef.current!, {
      controls: [
        "play-large",
        "play",
        "progress",
        "current-time",
        "mute",
        "volume",
        "settings",
        "fullscreen",
      ],
      settings: ["quality", "speed"],
      autoplay: false,
    });

    return () => player.destroy();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center space-x-2 text-sm text-gray-600 mb-4">
            <BookOpen className="h-4 w-4" />
            <span>{lesson.name}</span>
            <span>•</span>
            <span>{lesson.teacher}</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{"нет описания "}</h1>
          <div className="flex items-center space-x-6 text-sm text-gray-600">
            <div className="flex items-center space-x-1">
              <Clock className="h-4 w-4" />
              <span>{lesson.duration}</span>
            </div>
            {/* <div className="flex items-center space-x-1">
              <User className="h-4 w-4" />
              <span>{lesson.views} просмотров</span>
            </div> */}
            {/* <div className="flex items-center space-x-1">
              <Heart className="h-4 w-4" />
              <span>{lesson.likes} лайков</span>
            </div> */}
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Video Player */}
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="bg-black rounded-2xl overflow-hidden shadow-2xl">
              <div className="relative aspect-video">
                {/* YouTube видео через iframe */}
                <div ref={playerRef} className="plyr__video-embed">
                  <iframe
                    src="https://www.youtube.com/embed/M31rpHGUFu4"
                    allowFullScreen
                    allow="autoplay; encrypted-media"
                    title="Видео урок — SmartSchool.KG"
                  ></iframe>
                </div>

                {/* Подпись снизу */}
                {/* <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                  <div className="flex items-center space-x-2 text-white">
                    <p className="text-sm font-medium">Видео урок — SmartSchool.KG</p>
                  </div>
                </div> */}
              </div>
            </div>

            {/* Lesson Info */}
            <div className="mt-6 bg-white rounded-2xl shadow-xl p-6">
              {/* <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">Описание урока</h2>
                  <p className="text-gray-600">{lesson.description}</p>
                </div>
                <div className="flex space-x-2">
                  <button className="p-2 text-gray-400 hover:text-red-500 transition-colors">
                    <Heart className={`h-5 w-5 ${lesson.isLiked ? 'text-red-500 fill-current' : ''}`} />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-yellow-500 transition-colors">
                    <Bookmark className={`h-5 w-5 ${lesson.isBookmarked ? 'text-yellow-500 fill-current' : ''}`} />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors">
                    <Share2 className="h-5 w-5" />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors">
                    <Download className="h-5 w-5" />
                  </button>
                </div>
              </div> */}

              {/* Tabs */}
              <div className="border-b border-gray-200 mb-6">
                <nav className="flex space-x-8">
                  {[
                    { id: 'video', label: 'Видео' },
                    { id: 'materials', label: 'Материалы' },
                    { id: 'comments', label: 'Комментарии' }
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${activeTab === tab.id
                        ? 'border-primary-500 text-primary-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                        }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </nav>
              </div>

              {/* Tab Content */}
              {activeTab === 'video' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Цели урока</h3>
                    <ul className="space-y-2">
                      {/* {lesson.objectives.map((objective, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                          <span className="text-gray-700">{objective}</span>
                        </li>
                      ))} */}
                    </ul>
                  </div>
                </div>
              )}

              {activeTab === 'materials' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Материалы урока</h3>
                  {/* {lesson.materials.map((material, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="bg-primary-100 p-2 rounded-lg">
                          <BookOpen className="h-5 w-5 text-primary-600" />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">{material.name}</h4>
                          <p className="text-sm text-gray-600">{material.type.toUpperCase()} • {material.size}</p>
                        </div>
                      </div>
                      <button className="btn-primary flex items-center space-x-2">
                        <Download className="h-4 w-4" />
                        <span>Скачать</span>
                      </button>
                    </div>
                  ))} */}
                </div>
              )}

              {activeTab === 'comments' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Комментарии</h3>

                  {/* Comment Form */}
                  <div className="flex space-x-3 mb-6">
                    <img
                      src="/api/placeholder/40/40"
                      alt="Your avatar"
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <textarea
                        placeholder="Добавить комментарий..."
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent resize-none"
                        rows={3}
                      />
                      <div className="flex justify-end mt-2">
                        <button className="btn-primary">Отправить</button>
                      </div>
                    </div>
                  </div>

                  {/* Comments List */}
                  <div className="space-y-4">
                    {comments.map((comment, index) => (
                      <motion.div
                        key={comment.id}
                        className="flex space-x-3"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                      >
                        <img
                          src={comment.avatar}
                          alt={comment.author}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <div className="bg-gray-50 rounded-lg p-3">
                            <div className="flex items-center space-x-2 mb-1">
                              <span className="font-medium text-gray-900">{comment.author}</span>
                              <span className="text-xs text-gray-500">{comment.time}</span>
                            </div>
                            <p className="text-gray-700">{comment.text}</p>
                          </div>
                          <div className="flex items-center space-x-4 mt-2">
                            <button className="flex items-center space-x-1 text-sm text-gray-500 hover:text-gray-700">
                              <Heart className="h-4 w-4" />
                              <span>{comment.likes}</span>
                            </button>
                            <button className="text-sm text-gray-500 hover:text-gray-700">
                              Ответить
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>

          {/* Sidebar */}
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            {/* Teacher Info */}
            <div className="bg-white rounded-2xl shadow-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Преподаватель</h3>
              <div className="flex items-center space-x-3 mb-4">
                <img
                  src="/api/placeholder/50/50"
                  alt={lesson.teacher}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <h4 className="font-medium text-gray-900">{lesson.teacher}</h4>
                  <p className="text-sm text-gray-600">Учитель математики</p>
                </div>
              </div>
              <button className="w-full btn-secondary flex items-center justify-center space-x-2">
                <MessageCircle className="h-4 w-4" />
                <span>Написать сообщение</span>
              </button>
            </div>

            {/* Related Lessons */}
            <div className="bg-white rounded-2xl shadow-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Похожие уроки</h3>
              <div className="space-y-4">
                {[
                  { title: 'Линейные уравнения', duration: '25 мин', views: 892 },
                  { title: 'Системы уравнений', duration: '35 мин', views: 654 },
                  { title: 'Графики функций', duration: '40 мин', views: 1234 }
                ].map((relatedLesson, index) => (
                  <div key={index} className="flex items-center space-x-3 p-3 hover:bg-gray-50 rounded-lg cursor-pointer">
                    <div className="bg-primary-100 p-2 rounded-lg">
                      <Play className="h-4 w-4 text-primary-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 text-sm">{relatedLesson.title}</h4>
                      <p className="text-xs text-gray-600">{relatedLesson.duration} • {relatedLesson.views} просмотров</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Progress */}
            <div className="bg-white rounded-2xl shadow-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Прогресс</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-gray-600">Просмотр урока</span>
                    <span className="text-gray-900 font-medium">75%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-primary-600 h-2 rounded-full" style={{ width: '75%' }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-gray-600">Выполнение заданий</span>
                    <span className="text-gray-900 font-medium">60%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '60%' }}></div>
                  </div>
                </div>
                <button className="w-full btn-primary flex items-center justify-center space-x-2">
                  <ArrowRight className="h-4 w-4" />
                  <span>Продолжить обучение</span>
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}                                                                                                                                                                                                                                                                       
